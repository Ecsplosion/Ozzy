const upperField = document.getElementById('upper-field').value = "";
const lowerField = document.getElementById('lower-field').value = "";
const iprField = document.getElementById('ipr-field').value = "";