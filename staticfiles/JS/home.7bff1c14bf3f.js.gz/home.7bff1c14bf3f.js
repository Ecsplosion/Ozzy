let element_01 = document.getElementById('content-holder');
let element_02 = document.getElementById('extra-holder');
if(element_01){
    element_01.style.top = '230px';
}
if(element_02){
    element_02.style.display = 'block';
}